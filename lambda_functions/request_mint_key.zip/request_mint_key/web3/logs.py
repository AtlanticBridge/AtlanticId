from web3._utils.events import (
    EventLogErrorFlags,
)

DISCARD = EventLogErrorFlags.Discard
IGNORE = EventLogErrorFlags.Ignore
STRICT = EventLogErrorFlags.Strict
WARN = EventLogErrorFlags.Warn
